# hyprixs code, do not remove or i will have the rights to delete your bot
#
#
#
#
#
#
# double check
#
#
#
#
#
#
#

import discord
import aiohttp
import os
from discord.ext import commands, tasks
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


# Intents and bot setup
intents = discord.Intents.default()
intents.message_content = True  # Required for some commands
bot = commands.Bot(command_prefix="!", intents=intents)
token = "Yourtokenhere"
catapi = "Yourcatapikeyhere"

async def fetch_cat_image():
    """Fetch a random cat image from The Cat API."""
    url = f"https://api.thecatapi.com/v1/images/search?size=med&mime_types=jpg&format=json&has_breeds=true&order=RANDOM&page=0&limit=1&_={os.urandom(8).hex()}"
    headers = {"x-api-key":tapi}

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return data[0]["url"] if data else None
                return None
        except Exception as e:
            print(f"Error fetching cat image: {e}")
            return None

@bot.slash_command(name="search", description="Get a random cat image")
async def search(ctx):
    """Fetch and send a random cat image."""
    cat_image_url = await fetch_cat_image()
    if cat_image_url:
        await ctx.respond(cat_image_url)
    else:
        await ctx.respond("Couldn't fetch a cat image. Try again later!")

@tasks.loop(hours=1)
async def send_hourly_cat():
    """Send a random cat image to all servers every hour."""
    cat_image_url = await fetch_cat_image()
    if cat_image_url:
        for guild in bot.guilds:
            if guild.system_channel:  # Send in the default system channel
                try:
                    await guild.system_channel.send(cat_image_url)
                except discord.Forbidden:
                    print(f"Missing permissions in {guild.name}")
                except discord.HTTPException as e:
                    print(f"Failed to send in {guild.name}: {e}")

@bot.event
async def on_ready():
    """Event triggered when the bot is ready."""
    print(f"Logged in as {bot.user} or ({bot.user.id})")
    send_hourly_cat.start()

bot.run(token)

#
#
#
#
# Pycord version improved & checked
